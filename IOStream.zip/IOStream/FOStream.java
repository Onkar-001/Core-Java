import java.io.*;
class FOStream {
	public static void main(String[] args) throws FileNotFoundException, IOException {
	
	  FileOutputStream fos = new FileOutputStream("bbc.txt");

	  fos.write(97);
	 System.out.println("Data is Saved");
	fos.close();
	}
}