import java.io.*;
class FIStream {
	public static void main(String[] args) throws FileNotFoundException , IOException{
		FileInputStream fis = new FileInputStream("abc.txt");
		int data;
		while((data = fis.read()) != -1) {
			System.out.print(" "+ (char)data);
		}
	}
}
