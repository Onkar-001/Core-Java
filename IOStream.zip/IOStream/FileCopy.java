import java.io.*;
class FileCopy {
	public static void main(String[] args) throws FileNotFoundException , IOException {
		FileInputStream fis = new FileInputStream("sourceFile.txt");
		FileOutputStream fos = new FileOutputStream("destFile.txt");

		int data;
		while((data = fis.read()) != -1) {
			fos.write(data);
		}
		System.out.println("Data Copied");
		fis.close();
		fos.close();
	}
}