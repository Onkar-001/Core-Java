import java.io.*;
class FNFEOtTest {
	public static void main(String[] args) throws FileNotFoundException {
		FileOutputStream fos = new FileOutputStream("o.txt");

	}
}
// Leads to FileNotFoundException (FNFE)
// 1. unable create the file (in c drive we create only folder but not file)
// 2. file as folder/directory but not regular .txt file
// 3. file is available but does not have writing permission (its read only file)