import java.util.*;
import java.io.*;
class DynamicFileCopyScannerApp {
	public static void main(String[] args) throws  FileNotFoundException , IOException {

		Scanner sc = new Scanner(System.in);
		System.out.print("Enter src file : ");
		String srcFile = sc.next();
		System.out.print("Enter dest file : ");
		String destFile = sc.next();

		FileInputStream fis = new FileInputStream(srcFile);
		FileOutputStream fos = new FileOutputStream(destFile);
		int data;
		while((data = fis.read()) != -1){
			fos.write(data);
		}
		System.out.println("Data Copied");
		fis.close();
		fos.close();
		
	}
}