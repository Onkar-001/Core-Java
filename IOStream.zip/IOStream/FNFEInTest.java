import java.io.*;
class FNFEInTest {
	public static void main(String[] args) throws FileNotFoundException{
		FileInputStream fis = new FileInputStream("z.txt");
	}
}

// Leads to FileNotFoundException (FNFE)
// 1. file not available in system
// 2. file available but folder name with file name not valid
// 3. file available but required permission