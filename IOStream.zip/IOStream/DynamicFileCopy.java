import java.io.*;
class DynamicFileCopy {
	public static void main(String[] args) throws FileNotFoundException, IOException {
		FileInputStream fis = new FileInputStream(args[0]);
		FileOutputStream fos = new FileOutputStream(args[1]);
	
		int data; 
		while((data = fis.read())!= -1) {
			fos.write(data);			
		}
		System.out.println("Data Copied");
		fis.close();
		fos.close();
	}

}